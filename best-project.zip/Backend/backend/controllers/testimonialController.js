// controllers/testimonialController.js
const Testimonial = require("../models/Testimonial");
exports.getTestimonials = async (req, res) => {
  const testimonials = await Testimonial.find();
  res.json(testimonials);
};
exports.addTestimonial = async (req, res) => {
  const { name, role, image, logo, quote } = req.body;
  const testimonial = new Testimonial({ name, role, image, logo, quote });
  await testimonial.save();
  res.status(201).json({ message: "Testimonial added" });
};
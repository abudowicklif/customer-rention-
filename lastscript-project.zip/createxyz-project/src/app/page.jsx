"use client";
import React from "react";

function MainComponent() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [showDemo, setShowDemo] = useState(false);
  const [activeTab, setActiveTab] = useState("features");
  const [isVisible, setIsVisible] = useState(false);
  const [activeFaq, setActiveFaq] = useState(null);
  const [currentTestimonial, setCurrentTestimonial] = useState(0);
  const [showChat, setShowChat] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsVisible(window.scrollY > 300);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const [counts, setCounts] = useState({
    users: 0,
    rating: 0,
    satisfaction: 0,
  });

  useEffect(() => {
    const interval = setInterval(() => {
      setCounts((prev) => ({
        users: prev.users >= 10000 ? 10000 : prev.users + 100,
        rating: prev.rating >= 4.9 ? 4.9 : prev.rating + 0.1,
        satisfaction: prev.satisfaction >= 98 ? 98 : prev.satisfaction + 1,
      }));
    }, 50);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentTestimonial((prev) => (prev + 1) % testimonials.length);
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  const testimonials = [
    {
      name: "Sarah Johnson",
      role: "CEO, TechStart",
      image: "/testimonial1.jpg",
      logo: "/company1.png",
      quote:
        "StreatBreak transformed how we engage with customers. The AI insights are game-changing.",
    },
    {
      name: "Michael Chen",
      role: "Founder, GrowthLabs",
      image: "/testimonial2.jpg",
      logo: "/company2.png",
      quote:
        "The implementation was seamless, and our customer retention improved by 45%.",
    },
    {
      name: "Emma Davis",
      role: "Marketing Director",
      image: "/testimonial3.jpg",
      logo: "/company3.png",
      quote:
        "The analytics provided helped us make data-driven decisions that boosted sales.",
    },
  ];
  const faqs = [
    {
      question: "How quickly can I get started?",
      answer:
        "You can set up your account and launch your first campaign in under 5 minutes.",
    },
    {
      question: "Is there a free trial?",
      answer:
        "Yes, we offer a 30-day free trial with full access to all features.",
    },
    {
      question: "What kind of support do you offer?",
      answer:
        "24/7 customer support via chat, email, and phone, plus comprehensive documentation.",
    },
    {
      question: "Can I integrate with my existing systems?",
      answer:
        "Yes, we offer APIs and integrations with major business platforms.",
    },
  ];
  const features = [
    {
      icon: "brain",
      title: "AI-Powered Analytics",
      description:
        "Get deep insights into customer behavior using ChatGPT and Google Gemini. Understand trends, predict preferences, and automate responses.",
    },
    {
      icon: "image",
      title: "Visual Recognition",
      description:
        "Scan and analyze product images, receipts, and loyalty cards using DALL·E 3 and Stable Diffusion for instant reward processing.",
    },
    {
      icon: "globe",
      title: "Global Reach",
      description:
        "Communicate with customers in any language using Google Translate. Access worldwide business data for market insights.",
    },
    {
      icon: "qrcode",
      title: "Smart QR System",
      description:
        "Create unique QR codes for each customer. Track scans, visits, and rewards in real-time with detailed analytics.",
    },
    {
      icon: "search",
      title: "Smart Search",
      description:
        "Find customer records instantly. Compare prices and products across markets with real-time search tools.",
    },
    {
      icon: "map-marker-alt",
      title: "Location Services",
      description:
        "Auto-complete addresses and find nearby businesses. Optimize store locations based on customer traffic.",
    },
    {
      icon: "eye",
      title: "Vision AI",
      description:
        "Verify customer identity and validate receipts automatically with GPT-4 Vision. Prevent fraud and streamline processing.",
    },
    {
      icon: "chart-line",
      title: "Web Analytics",
      description:
        "Track customer engagement, monitor competitors, and gather market data with advanced web analysis tools.",
    },
  ];
  const trustedCompanies = [
    { name: "Microsoft", logo: "/microsoft.png" },
    { name: "Google", logo: "/google.png" },
    { name: "Amazon", logo: "/amazon.png" },
    { name: "Apple", logo: "/apple.png" },
    { name: "Meta", logo: "/meta.png" },
    { name: "Netflix", logo: "/netflix.png" },
  ];
  const latestNews = [
    {
      title: "StreatBreak Named Top SaaS Product 2025",
      date: "March 15, 2025",
      image: "/news1.jpg",
      link: "#",
    },
    {
      title: "How AI is Transforming Customer Loyalty",
      date: "March 10, 2025",
      image: "/news2.jpg",
      link: "#",
    },
    {
      title: "Customer Success Story: TechStart's Journey",
      date: "March 5, 2025",
      image: "/news3.jpg",
      link: "#",
    },
  ];
  const steps = [
    { number: 1, text: "Sign Up" },
    { number: 2, text: "Create Program" },
    { number: 3, text: "Print QR Code" },
    { number: 4, text: "Start Rewarding" },
  ];
  const footerLinks = {
    Product: ["Features", "Pricing", "Demo"],
    Resources: ["Guide", "Support", "API"],
    Contact: ["Email", "Phone", "Chat"],
  };
  const FeatureCard = ({ icon, title, description }) => (
    <div className="bg-white p-8 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 border border-[#e2e8f0] transform hover:scale-105">
      <div className="bg-[#4f46e5]/10 w-16 h-16 rounded-lg flex items-center justify-center mb-6">
        <i className={`fas fa-${icon} text-[#4f46e5] text-3xl`}></i>
      </div>
      <h3 className="text-2xl font-bold text-[#0f172a] mb-4">{title}</h3>
      <p className="text-[#475569] leading-relaxed">{description}</p>
    </div>
  );
  const PricingCard = ({ title, price, features, recommended }) => (
    <div
      className={`bg-white p-8 rounded-xl shadow-lg ${
        recommended
          ? "border-2 border-[#4f46e5] relative"
          : "border border-[#e2e8f0]"
      }`}
    >
      {recommended && (
        <div className="absolute top-0 right-0 bg-[#4f46e5] text-white px-4 py-1 rounded-bl-lg rounded-tr-lg text-sm">
          Recommended
        </div>
      )}
      <h3 className="text-2xl font-bold text-[#0f172a] mb-2">{title}</h3>
      <div className="text-4xl font-bold text-[#4f46e5] mb-6">
        {price === "Custom" ? price : `${price}`}
        {price !== "Custom" && (
          <span className="text-lg text-[#475569]">/mo</span>
        )}
      </div>
      <ul className="space-y-3 mb-8">
        {features.map((feature, index) => (
          <li key={index} className="flex items-center">
            <i className="fas fa-check text-[#4f46e5] mr-2"></i>
            <span className="text-[#475569]">{feature}</span>
          </li>
        ))}
      </ul>
      <button
        className={`w-full py-3 rounded-lg ${
          recommended
            ? "bg-[#4f46e5] text-white"
            : "border-2 border-[#4f46e5] text-[#4f46e5]"
        }`}
      >
        Get Started
      </button>
    </div>
  );

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#f8fafc] to-[#e2e8f0] scroll-smooth">
      <nav className="bg-white shadow-lg">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex justify-between h-16">
            <div className="flex items-center">
              <span className="text-2xl font-bold text-[#0f172a] font-poppins">
                StreatBreak
              </span>
            </div>

            <div className="hidden md:flex items-center space-x-8">
              <a
                className="text-[#334155] hover:text-[#0f172a] font-medium"
                href="#features"
              >
                Features
              </a>
              <a
                className="text-[#334155] hover:text-[#0f172a] font-medium"
                href="#pricing"
              >
                Pricing
              </a>
              <button className="bg-[#3b82f6] text-white px-6 py-2 rounded-lg hover:bg-[#2563eb] transition-colors">
                Get Started
              </button>
            </div>

            <div className="md:hidden flex items-center">
              <button
                onClick={() => setIsMenuOpen(!isMenuOpen)}
                className="text-[#334155]"
              >
                <i
                  className={`fas ${
                    isMenuOpen ? "fa-times" : "fa-bars"
                  } text-2xl`}
                ></i>
              </button>
            </div>
          </div>
        </div>
      </nav>

      {isMenuOpen && (
        <div className="md:hidden bg-white shadow-lg">
          <a
            className="block px-4 py-2 text-[#334155] hover:bg-[#f1f5f9]"
            href="#features"
          >
            Features
          </a>
          <a
            className="block px-4 py-2 text-[#334155] hover:bg-[#f1f5f9]"
            href="#demo"
          >
            Demo
          </a>
          <div className="px-4 py-2">
            <button className="w-full bg-[#3b82f6] text-white px-6 py-2 rounded-lg hover:bg-[#2563eb]">
              Sign Up
            </button>
          </div>
        </div>
      )}

      <main className="max-w-7xl mx-auto px-4 py-16">
        <div className="text-center mb-16 relative">
          <div className="absolute inset-0 bg-gradient-to-r from-[#4f46e5] to-[#06b6d4] opacity-5 rounded-3xl"></div>
          <h1 className="text-5xl md:text-7xl font-bold text-[#0f172a] mb-6 font-poppins leading-tight">
            Transform Your <span className="text-[#4f46e5]">Business</span>
            <br />
            Into a Digital Success
          </h1>
          <p className="text-xl md:text-2xl text-[#475569] mb-12 max-w-3xl mx-auto font-light">
            Elevate your customer experience with our smart loyalty system. Join
            thousands of successful businesses.
          </p>
          <div className="flex flex-col md:flex-row justify-center gap-6">
            <button className="group bg-gradient-to-r from-[#4f46e5] to-[#06b6d4] text-white px-10 py-4 rounded-xl text-lg hover:shadow-lg hover:shadow-[#4f46e5]/20 transition-all duration-300">
              Get Started Free
              <i className="fas fa-arrow-right ml-2 group-hover:translate-x-1 transition-transform"></i>
            </button>
            <button className="bg-white border-2 border-[#4f46e5] text-[#4f46e5] px-10 py-4 rounded-xl text-lg hover:bg-[#4f46e5] hover:text-white transition-all duration-300">
              Watch Demo
              <i className="fas fa-play ml-2"></i>
            </button>
          </div>
        </div>

        <div className="mb-16 py-12 border-y border-[#e2e8f0]">
          <h2 className="text-2xl font-bold text-center mb-8">
            Trusted By Industry Leaders
          </h2>
          <div className="flex flex-wrap justify-center items-center gap-12">
            {trustedCompanies.map((company) => (
              <img
                key={company.name}
                src={company.logo}
                alt={`${company.name} logo`}
                className="h-8 md:h-12 opacity-50 hover:opacity-100 transition-opacity"
              />
            ))}
          </div>
        </div>

        <div className="text-center mb-16">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
            <div className="bg-white p-8 rounded-xl shadow-lg">
              <div className="text-4xl font-bold text-[#4f46e5] mb-2">
                {counts.users.toLocaleString()}+
              </div>
              <div className="text-[#475569]">Active Users</div>
            </div>
            <div className="bg-white p-8 rounded-xl shadow-lg">
              <div className="text-4xl font-bold text-[#4f46e5] mb-2">
                {counts.rating.toFixed(1)}/5
              </div>
              <div className="text-[#475569]">Average Rating</div>
            </div>
            <div className="bg-white p-8 rounded-xl shadow-lg">
              <div className="text-4xl font-bold text-[#4f46e5] mb-2">
                {counts.satisfaction}%
              </div>
              <div className="text-[#475569]">Customer Satisfaction</div>
            </div>
          </div>
        </div>

        <div className="grid md:grid-cols-4 gap-8 mb-16">
          {features.map((feature, index) => (
            <FeatureCard key={index} {...feature} />
          ))}
        </div>

        <div className="mb-16">
          <h2 className="text-3xl font-bold text-center mb-12">
            Choose Your Plan
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <PricingCard
              title="Starter"
              price="29"
              features={[
                "Up to 1,000 customers",
                "Basic analytics",
                "Email support",
                "API access",
              ]}
            />
            <PricingCard
              title="Professional"
              price="99"
              features={[
                "Up to 10,000 customers",
                "Advanced analytics",
                "24/7 support",
                "API access",
                "Custom integrations",
              ]}
              recommended={true}
            />
            <PricingCard
              title="Enterprise"
              price="Custom"
              features={[
                "Unlimited customers",
                "Custom solutions",
                "Dedicated support",
                "Custom development",
                "SLA guarantee",
              ]}
            />
          </div>
        </div>

        <div className="mb-16">
          <h2 className="text-3xl font-bold text-center mb-12">
            What Our Customers Say
          </h2>
          <div className="relative overflow-hidden">
            <div
              className="flex transition-transform duration-500"
              style={{ transform: `translateX(-${currentTestimonial * 100}%)` }}
            >
              {testimonials.map((testimonial, index) => (
                <div key={index} className="w-full flex-shrink-0">
                  <div className="bg-white p-8 rounded-xl shadow-lg max-w-2xl mx-auto">
                    <div className="flex items-center mb-6">
                      <img
                        src={testimonial.image}
                        alt={testimonial.name}
                        className="w-16 h-16 rounded-full mr-4"
                      />
                      <div>
                        <div className="font-bold text-lg">
                          {testimonial.name}
                        </div>
                        <div className="text-[#475569]">{testimonial.role}</div>
                      </div>
                      <img
                        src={testimonial.logo}
                        alt="Company logo"
                        className="h-8 ml-auto"
                      />
                    </div>
                    <p className="text-lg text-[#475569] italic">
                      {testimonial.quote}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="mb-16">
          <h2 className="text-3xl font-bold text-center mb-12">
            Frequently Asked Questions
          </h2>
          <div className="max-w-2xl mx-auto">
            {faqs.map((faq, index) => (
              <div key={index} className="mb-4">
                <button
                  className="w-full text-left p-4 bg-white rounded-lg shadow-sm hover:shadow-md transition-shadow flex justify-between items-center"
                  onClick={() =>
                    setActiveFaq(activeFaq === index ? null : index)
                  }
                >
                  <span className="font-medium">{faq.question}</span>
                  <i
                    className={`fas fa-chevron-${
                      activeFaq === index ? "up" : "down"
                    } text-[#4f46e5]`}
                  ></i>
                </button>
                <div
                  className={`bg-white px-4 rounded-b-lg overflow-hidden transition-all duration-300 ${
                    activeFaq === index ? "max-h-40 py-4" : "max-h-0"
                  }`}
                >
                  {faq.answer}
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="mb-16">
          <h2 className="text-3xl font-bold text-center mb-12">
            Latest News & Resources
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {latestNews.map((news, index) => (
              <a key={index} href={news.link} className="group">
                <div className="bg-white rounded-xl shadow-lg overflow-hidden">
                  <img
                    src={news.image}
                    alt={news.title}
                    className="w-full h-48 object-cover"
                  />
                  <div className="p-6">
                    <div className="text-sm text-[#475569] mb-2">
                      {news.date}
                    </div>
                    <h3 className="font-bold text-lg group-hover:text-[#4f46e5] transition-colors">
                      {news.title}
                    </h3>
                  </div>
                </div>
              </a>
            ))}
          </div>
        </div>

        <div className="text-center bg-[#f8fafc] p-8 rounded-xl">
          <h2 className="text-3xl font-bold text-[#0f172a] mb-6">
            Start Growing Your Business Today
          </h2>
          <p className="text-[#475569] mb-6">
            30-day free trial • No credit card required
          </p>
          <button className="bg-[#4f46e5] text-white px-8 py-3 rounded-lg text-lg hover:bg-[#2563eb] transition-colors animate-pulse">
            Create Your Account
          </button>
        </div>
      </main>

      <footer className="bg-[#0f172a] text-white py-8 mt-16">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <h3 className="text-xl font-bold mb-4">StreatBreak</h3>
              <p className="text-[#94a3b8]">Business Growth Made Simple</p>
            </div>
            {Object.entries(footerLinks).map(([title, items]) => (
              <div key={title}>
                <h4 className="font-bold mb-4">{title}</h4>
                <ul className="space-y-2 text-[#94a3b8]">
                  {items.map((item) => (
                    <li key={item}>{item}</li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </footer>

      {isVisible && (
        <button
          onClick={() => setShowDemo(true)}
          className="fixed bottom-8 right-8 bg-gradient-to-r from-[#4f46e5] to-[#06b6d4] text-white px-6 py-3 rounded-full shadow-lg hover:shadow-xl transition-all duration-300 animate-bounce z-50"
        >
          <i className="fas fa-calendar-check mr-2"></i>
          Book Demo
        </button>
      )}

      {showChat && (
        <div className="fixed bottom-24 right-8 bg-white p-4 rounded-lg shadow-xl z-50 w-[300px]">
          <div className="flex justify-between items-center mb-4">
            <h3 className="font-bold">Chat Support</h3>
            <button onClick={() => setShowChat(false)}>
              <i className="fas fa-times"></i>
            </button>
          </div>
          <div className="bg-gray-100 p-3 rounded">
            <p className="text-sm">Hi! How can we help you today?</p>
          </div>
        </div>
      )}

      <button
        onClick={() => setShowChat(true)}
        className="fixed bottom-8 right-8 bg-[#4f46e5] text-white w-12 h-12 rounded-full shadow-lg hover:shadow-xl transition-all duration-300 flex items-center justify-center animate-pulse z-50"
      >
        <i className="fas fa-comments text-xl"></i>
      </button>

      <style jsx global>{`
        @keyframes slideIn {
          from { transform: translateY(20px); opacity: 0; }
          to { transform: translateY(0); opacity: 1; }
        }
        @keyframes fadeIn {
          from { opacity: 0; }
          to { opacity: 1; }
        }
        @keyframes scaleIn {
          from { transform: scale(0.9); opacity: 0; }
          to { transform: scale(1); opacity: 1; }
        }
        @keyframes pulse {
          0% { transform: scale(1); }
          50% { transform: scale(1.05); }
          100% { transform: scale(1); }
        }
        @keyframes slideInRight {
          from { transform: translateX(100%); }
          to { transform: translateX(0); }
        }
`}</style>
    </div>
  );
}

export default MainComponent;